class LeNet5(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.conv.Conv2d
  conv2 : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  relu1 : __torch__.torch.nn.modules.activation.ReLU
  relu2 : __torch__.torch.nn.modules.activation.___torch_mangle_1.ReLU
  pool1 : __torch__.torch.nn.modules.pooling.MaxPool2d
  pool2 : __torch__.torch.nn.modules.pooling.___torch_mangle_2.MaxPool2d
  linear : __torch__.torch.nn.modules.linear.Linear
  act : __torch__.torch.nn.modules.activation.Softmax
  def forward(self: __torch__.lenet5_net.LeNet5,
    x: Tensor) -> Tensor:
    act = self.act
    linear = self.linear
    pool2 = self.pool2
    relu2 = self.relu2
    conv2 = self.conv2
    pool1 = self.pool1
    relu1 = self.relu1
    conv1 = self.conv1
    _0 = (relu1).forward((conv1).forward(x, ), )
    _1 = (conv2).forward((pool1).forward(_0, ), )
    _2 = (pool2).forward((relu2).forward(_1, ), )
    _3 = ops.prim.NumToTensor(torch.size(_2, 0))
    input = torch.view(_2, [int(_3), -1])
    _4 = (act).forward((linear).forward(input, ), )
    return _4
